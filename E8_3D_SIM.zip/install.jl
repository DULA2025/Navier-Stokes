using Pkg

# Activate the project environment in the current directory
Pkg.activate(".")

# Clear package cache to resolve potential corruption
Pkg.rm("GLMakie")
Pkg.rm("CUDA")
Pkg.rm("StaticArrays")
Pkg.rm("GeometryBasics")
Pkg.rm("Colors")
Pkg.gc()  # Garbage collect unused packages
Pkg.precompile()  # Precompile to clear cache issues

# List of required packages
packages = ["GLMakie", "CUDA", "StaticArrays", "GeometryBasics", "Colors"]

# Install each package with error handling
for pkg in packages
    try
        Pkg.add(pkg)
        println("Successfully added $pkg")
    catch e
        println("Error adding $pkg: $e")
        # Attempt to update and retry
        try
            Pkg.update(pkg)
            Pkg.add(pkg)
            println("Retried and successfully added $pkg after update")
        catch e2
            println("Failed to recover $pkg: $e2")
        end
    end
end

# Instantiate the project environment with error handling
try
    Pkg.instantiate()
    println("Project environment instantiated successfully")
catch e
    println("Error instantiating project environment: $e")
    # Attempt to resolve by updating all packages
    try
        Pkg.update()
        Pkg.instantiate()
        println("Recovered project environment after update")
    catch e2
        println("Failed to recover project environment: $e2")
    end
end