using GLMakie, CUDA, StaticArrays, Random, LinearAlgebra
using Colors      # For RGBA color definitions
using GeometryBasics  # For Rect3f primitive

# DULA-E8 Core Engine for 3D Navier-Stokes
module DULA_E8
export FluidSim3D

using CUDA, StaticArrays, GLMakie, Random, LinearAlgebra
using GeometryBasics
using Colors

# --- Simulation Core (E8 Math, Data Structures) ---
function e8_primes(N_primes::Int)
    is_prime(n) = n > 1 && all(n % i != 0 for i in 2:floor(Int, sqrt(n)))
    return [p for p in 2:N_primes+1 if is_prime(p)]
end

function e8_root(p, chi_p)
    if chi_p == 0; return SVector{8, Float64}(zeros(Float64, 8)); end
    scale = log(p) / sqrt(8.0)
    v1 = sin(p*0.1); v2 = cos(p*0.2); v3 = sin(p*0.3)+cos(p*0.4); v4 = sin(p*0.5)
    v5 = cos(p*0.6)+sin(p*0.7); v6 = sin(p*0.8); v7 = cos(p*0.9)*sin(p*0.11); v8 = sin(p*1.2)+cos(p*0.13)
    v = SVector{8, Float64}(v1, v2, v3, v4, v5, v6, v7, v8)
    return chi_p * scale * normalize(v)
end

function weyl_reflection(v::SVector{8, Float64}, plane_normal::SVector{8, Float64})
    unit_normal = normalize(plane_normal)
    return v - 2 * dot(v, unit_normal) * unit_normal
end

function initialize_e8_vectors(N::Int)
    primes = e8_primes(N)
    plane = SVector{8, Float64}(1,0,0,0,0,0,0,0)
    return [begin
        chi_p = p%2==0||p%3==0 ? 0 : (p%6==1 ? 1 : -1)
        v = chi_p==0 ? SVector{8, Float64}(zeros(Float64, 8)) : e8_root(Float64(p), Float64(chi_p))
        weyl_reflection(v, plane)
    end for p in primes]
end

mutable struct FluidGrids
    vel::CuArray{SVector{3, Float64}, 3}; vel0::CuArray{SVector{3, Float64}, 3}
    dens::CuArray{Float64, 3}; dens0::CuArray{Float64, 3}
    pres::CuArray{Float64, 3}; pres0::CuArray{Float64, 3}
    diverg::CuArray{Float64, 3}
end

function create_grids(NX, NY, NZ)
    if !CUDA.functional(); error("CUDA device not available"); end
    Vel0 = SVector{3, Float64}(0,0,0); Dens0 = 0.0
    vel = CuArray(fill(Vel0, NX, NY, NZ)); vel0 = CuArray(fill(Vel0, NX, NY, NZ))
    dens = CuArray(fill(Dens0, NX, NY, NZ)); dens0 = CuArray(fill(Dens0, NX, NY, NZ))
    pres = CuArray(fill(Dens0, NX, NY, NZ)); pres0 = CuArray(fill(Dens0, NX, NY, NZ))
    diverg = CuArray(fill(Dens0, NX, NY, NZ))
    return FluidGrids(vel, vel0, dens, dens0, pres, pres0, diverg)
end

@inline function gpu_clamp(x::Float64, min_val::Float64, max_val::Float64)
    return max(min(x, max_val), min_val)
end

# --- Corrected and Simplified CUDA Kernels ---
function advection_kernel!(vel, vel0, dens, dens0, dt, NX, NY, NZ)
    idx = (blockIdx().x-1)*blockDim().x+threadIdx().x; idy = (blockIdx().y-1)*blockDim().y+threadIdx().y; idz = (blockIdx().z-1)*blockDim().z+threadIdx().z
    if idx <= NX && idy <= NY && idz <= NZ && (idx>=2 && idx<=NX-1 && idy>=2 && idy<=NY-1 && idz>=2 && idz<=NZ-1)
        v = vel[idx,idy,idz]; x_pos=idx-dt*v[1]; y_pos=idy-dt*v[2]; z_pos=idz-dt*v[3]
        x_pos=gpu_clamp(x_pos,1.5,Float64(NX-0.5)); y_pos=gpu_clamp(y_pos,1.5,Float64(NY-0.5)); z_pos=gpu_clamp(z_pos,1.5,Float64(NZ-0.5))
        i0=Int(floor(x_pos)); i1=i0+1; j0=Int(floor(y_pos)); j1=j0+1; k0=Int(floor(z_pos)); k1=k0+1
        fx=x_pos-i0; fy=y_pos-j0; fz=z_pos-k0
        i0=max(min(i0,NX),1); j0=max(min(j0,NY),1); k0=max(min(k0,NZ),1); i1=max(min(i1,NX),1); j1=max(min(j1,NY),1); k1=max(min(k1,NZ),1)
        v000=vel[i0,j0,k0]; v010=vel[i0,j1,k0]; v100=vel[i1,j0,k0]; v110=vel[i1,j1,k0]; v001=vel[i0,j0,k1]; v011=vel[i0,j1,k1]; v101=vel[i1,j0,k1]; v111=vel[i1,j1,k1]
        u_interp=((v000[1]*(1-fx)+v100[1]*fx)*(1-fy)+(v010[1]*(1-fx)+v110[1]*fx)*fy)*(1-fz)+((v001[1]*(1-fx)+v101[1]*fx)*(1-fy)+(v011[1]*(1-fx)+v111[1]*fx)*fy)*fz
        v_interp=((v000[2]*(1-fx)+v100[2]*fx)*(1-fy)+(v010[2]*(1-fx)+v110[2]*fx)*fy)*(1-fz)+((v001[2]*(1-fx)+v101[2]*fx)*(1-fy)+(v011[2]*(1-fx)+v111[2]*fx)*fy)*fz
        w_interp=((v000[3]*(1-fx)+v100[3]*fx)*(1-fy)+(v010[3]*(1-fx)+v110[3]*fx)*fy)*(1-fz)+((v001[3]*(1-fx)+v101[3]*fx)*(1-fy)+(v011[3]*(1-fx)+v111[3]*fx)*fy)*fz
        vel0[idx,idy,idz]=SVector{3,Float64}(u_interp,v_interp,w_interp)
        d000=dens[i0,j0,k0]; d100=dens[i1,j0,k0]; d010=dens[i0,j1,k0]; d110=dens[i1,j1,k0]; d001=dens[i0,j0,k1]; d101=dens[i1,j0,k1]; d011=dens[i0,j1,k1]; d111=dens[i1,j1,k1]
        dens0[idx,idy,idz]=((d000*(1-fx)+d100*fx)*(1-fy)+(d010*(1-fx)+d110*fx)*fy)*(1-fz)+((d001*(1-fx)+d101*fx)*(1-fy)+(d011*(1-fx)+d111*fx)*fy)*fz
    end; return
end

function diffusion_kernel!(vel, vel0, visc, dt, NX, NY, NZ)
    idx = (blockIdx().x-1)*blockDim().x+threadIdx().x; idy = (blockIdx().y-1)*blockDim().y+threadIdx().y; idz = (blockIdx().z-1)*blockDim().z+threadIdx().z
    if idx <= NX && idy <= NY && idz <= NZ && (idx>=2 && idx<=NX-1 && idy>=2 && idy<=NY-1 && idz>=2 && idz<=NZ-1)
        v_c = vel0[idx,idy,idz]; v_l=vel0[idx-1,idy,idz]; v_r=vel0[idx+1,idy,idz]; v_b=vel0[idx,idy-1,idz]; v_t=vel0[idx,idy+1,idz]; v_f=vel0[idx,idy,idz-1]; v_bk=vel0[idx,idy,idz+1]
        alpha = visc*dt*NX*NY*NZ; beta = 1.0/(1.0+6.0*alpha)
        vel[idx,idy,idz] = beta*(v_c+alpha*(v_l+v_r+v_b+v_t+v_f+v_bk))
    end; return
end

function divergence_kernel!(diverg, vel, NX, NY, NZ)
    idx=(blockIdx().x-1)*blockDim().x+threadIdx().x; idy=(blockIdx().y-1)*blockDim().y+threadIdx().y; idz=(blockIdx().z-1)*blockDim().z+threadIdx().z
    if idx<=NX && idy<=NY && idz<=NZ && (idx>=2 && idx<=NX-1 && idy>=2 && idy<=NY-1 && idz>=2 && idz<=NZ-1)
        u_l=vel[idx-1,idy,idz][1]; u_r=vel[idx+1,idy,idz][1]; v_b=vel[idx,idy-1,idz][2]; v_t=vel[idx,idy+1,idz][2]; w_f=vel[idx,idy,idz-1][3]; w_b=vel[idx,idy,idz+1][3]
        diverg[idx,idy,idz] = 0.5*((u_r-u_l)+(v_t-v_b)+(w_b-w_f))
    end; return
end

function jacobi_kernel!(pres, pres0, diverg, alpha, beta, NX, NY, NZ)
    idx=(blockIdx().x-1)*blockDim().x+threadIdx().x; idy=(blockIdx().y-1)*blockDim().y+threadIdx().y; idz=(blockIdx().z-1)*blockDim().z+threadIdx().z
    if idx<=NX && idy<=NY && idz<=NZ && (idx>=2 && idx<=NX-1 && idy>=2 && idy<=NY-1 && idz>=2 && idz<=NZ-1)
        p_l=pres0[idx-1,idy,idz]; p_r=pres0[idx+1,idy,idz]; p_b=pres0[idx,idy-1,idz]; p_t=pres0[idx,idy+1,idz]; p_f=pres0[idx,idy,idz-1]; p_bk=pres0[idx,idy,idz+1]
        pres[idx,idy,idz] = (p_l+p_r+p_b+p_t+p_f+p_bk+alpha*diverg[idx,idy,idz])*beta
    end; return
end

function gradient_kernel!(vel, pres, NX, NY, NZ)
    idx=(blockIdx().x-1)*blockDim().x+threadIdx().x; idy=(blockIdx().y-1)*blockDim().y+threadIdx().y; idz=(blockIdx().z-1)*blockDim().z+threadIdx().z
    if idx<=NX && idy<=NY && idz<=NZ && (idx>=2 && idx<=NX-1 && idy>=2 && idy<=NY-1 && idz>=2 && idz<=NZ-1)
        p_l=pres[idx-1,idy,idz]; p_r=pres[idx+1,idy,idz]; p_b=pres[idx,idy-1,idz]; p_t=pres[idx,idy+1,idz]; p_f=pres[idx,idy,idz-1]; p_bk=pres[idx,idy,idz+1]
        vel[idx,idy,idz] -= 0.5*SVector{3,Float64}(p_r-p_l, p_t-p_b, p_bk-p_f)
    end; return
end

function boundary_kernel!(vel, NX, NY, NZ)
    idx=(blockIdx().x-1)*blockDim().x+threadIdx().x; idy=(blockIdx().y-1)*blockDim().y+threadIdx().y; idz=(blockIdx().z-1)*blockDim().z+threadIdx().z
    if idx<=NX && idy<=NY && idz<=NZ
        v=vel[idx,idy,idz]
        if idx==1||idx==NX; v=SVector{3,Float64}(-v[1],v[2],v[3]); end
        if idy==1||idy==NY; v=SVector{3,Float64}(v[1],-v[2],v[3]); end
        if idz==1||idz==NZ; v=SVector{3,Float64}(v[1],v[2],-v[3]); end
        vel[idx,idy,idz]=v
    end; return
end

function force_kernel!(vel, dens, inflow_u, inflow_v, inflow_w, NX, NY, NZ, obstacle_center, obstacle_radius)
    idx=(blockIdx().x-1)*blockDim().x+threadIdx().x; idy=(blockIdx().y-1)*blockDim().y+threadIdx().y; idz=(blockIdx().z-1)*blockDim().z+threadIdx().z
    if idx<=NX && idy<=NY && idz<=NZ
        if idx<10; vel[idx,idy,idz]=SVector{3,Float64}(inflow_u,inflow_v,inflow_w); dens[idx,idy,idz]=10.0; end
        cx,cy,cz = obstacle_center; r = obstacle_radius
        if abs(idx - cx) <= r && abs(idy - cy) <= r && abs(idz - cz) <= r
            vel[idx,idy,idz]=SVector{3,Float64}(0,0,0); dens[idx,idy,idz]=-5.0
        end
    end; return
end

function step!(grids, dt, visc, diff, iterations, NX, NY, NZ, inflow_u, inflow_v, inflow_w, obstacle_center, obstacle_radius)
    block_size=(8,8,4); grid_size=(cld(NX,block_size[1]), cld(NY,block_size[2]), cld(NZ,block_size[3]))
    grids.vel0.=grids.vel; grids.dens0.=grids.dens
    @cuda blocks=grid_size threads=block_size advection_kernel!(grids.vel,grids.vel0,grids.dens,grids.dens0,dt,NX,NY,NZ)
    CUDA.synchronize(); grids.vel.=grids.vel0; grids.dens.=grids.dens0
    @cuda blocks=grid_size threads=block_size diffusion_kernel!(grids.vel,grids.vel0,visc,dt,NX,NY,NZ)
    CUDA.synchronize(); grids.vel.=grids.vel0
    @cuda blocks=grid_size threads=block_size force_kernel!(grids.vel,grids.dens,inflow_u,inflow_v,inflow_w,NX,NY,NZ,obstacle_center,obstacle_radius)
    CUDA.synchronize()
    @cuda blocks=grid_size threads=block_size divergence_kernel!(grids.diverg,grids.vel,NX,NY,NZ)
    CUDA.synchronize(); grids.pres0.=0
    alpha=-1.0; beta=1.0/6.0
    for _=1:iterations
        @cuda blocks=grid_size threads=block_size jacobi_kernel!(grids.pres,grids.pres0,grids.diverg,alpha,beta,NX,NY,NZ)
        CUDA.synchronize(); grids.pres,grids.pres0=grids.pres0,grids.pres
    end
    @cuda blocks=grid_size threads=block_size gradient_kernel!(grids.vel,grids.pres,NX,NY,NZ)
    CUDA.synchronize()
    @cuda blocks=grid_size threads=block_size boundary_kernel!(grids.vel,NX,NY,NZ)
    CUDA.synchronize()
end

# --- Visualization and Interaction ---
mutable struct FluidSim3D
    NX::Int; NY::Int; NZ::Int
    grids::FluidGrids
    dt::Float64; visc::Float64; diff::Float64; iterations::Int
    obstacle_center::Tuple{Float64, Float64, Float64}
    obstacle_radius::Float64
    fig::Figure; ax::Axis3
    density_observable::Observable{Array{Float64, 3}}
    obstacle_observable::Observable{Rect3f}
    is_dragging::Bool; last_mouse_pos::Tuple{Float64, Float64}

    function FluidSim3D(NX, NY, NZ)
        grids = create_grids(NX, NY, NZ)
        fig = Figure(size=(800, 600), backgroundcolor=:white)
        ax = Axis3(fig[1, 1], aspect=:data, title="DULA-E8 Fluid Simulation",
                   elevation = pi/6, azimuth = pi/4, limits = (1, NX, 1, NY, 1, NZ))

        density_observable = Observable(zeros(Float64, NX, NY, NZ))
        obstacle_pos = (Float64(NX/2), Float64(NY/2), Float64(NY/2))
        obstacle_radius = 10.0
        
        origin = Point3f(obstacle_pos...) .- Point3f(obstacle_radius, obstacle_radius, obstacle_radius)
        widths = Vec3f(2*obstacle_radius, 2*obstacle_radius, 2*obstacle_radius)
        obstacle_observable = Observable(Rect3f(origin, widths))

        # MODIFIED: dt is multiplied by 32 for 32x faster simulation
        sim_dt = 0.016 * 32.0

        sim = new(NX, NY, NZ, grids, sim_dt, 0.00005, 0.0001, 20,
                  obstacle_pos, obstacle_radius, fig, ax,
                  density_observable, obstacle_observable,
                  false, (0.0, 0.0)) # Added is_dragging and last_mouse_pos
        create_plots!(sim)
        return sim
    end
end

function create_plots!(sim::FluidSim3D)
    custom_prolonged_colormap = [
        RGBA(0.0, 0.0, 0.5, 0.5), RGBA(0.0, 0.2, 0.7, 0.6),
        RGBA(0.0, 0.5, 1.0, 0.7), RGBA(0.0, 0.7, 0.5, 0.8),
        RGBA(0.5, 1.0, 0.0, 0.85), RGBA(1.0, 0.7, 0.0, 0.9),
        RGBA(1.0, 0.3, 0.0, 0.95), RGBA(1.0, 0.0, 0.0, 1.0)
    ]

    mesh!(sim.ax, sim.obstacle_observable, color=:red, shading=true)

    x_range = 1..sim.NX; y_range = 1..sim.NY; z_range = 1..sim.NZ
    volume!(sim.ax, x_range, y_range, z_range, sim.density_observable,
            algorithm=:absorption, colormap=custom_prolonged_colormap,
            colorrange=(-5.0, 10.0), transparency=true)
end

function visualize(sim::FluidSim3D)
    sim.density_observable[] = Array(sim.grids.dens)
    
    center = Point3f(sim.obstacle_center...)
    radius = sim.obstacle_radius
    origin = center .- Point3f(radius, radius, radius)
    widths = Vec3f(2*radius, 2*radius, 2*radius)
    sim.obstacle_observable[] = Rect3f(origin, widths)

    # MODIFIED: Re-enabled mouse and keyboard interaction
    on(events(sim.fig).mousebutton) do event
        if event.button==Mouse.left && event.action==Mouse.press
            sim.is_dragging=true
            sim.last_mouse_pos=event.data
        elseif event.button==Mouse.left && event.action==Mouse.release
            sim.is_dragging=false
        end
    end

    on(events(sim.fig).mouseposition) do pos
        if sim.is_dragging
            dx=pos[1]-sim.last_mouse_pos[1]; dy=pos[2]-sim.last_mouse_pos[2]
            new_cx = sim.obstacle_center[1] + dx/5; new_cy = sim.obstacle_center[2] - dy/5
            sim.obstacle_center = (clamp(new_cx,1.0,Float64(sim.NX)), clamp(new_cy,1.0,Float64(sim.NY)), sim.obstacle_center[3])
            sim.last_mouse_pos = pos
        end
    end

    on(events(sim.fig).keyboardbutton) do event
        if event.action == Keyboard.press
            speed = 2.0 # Grid units per key press
            new_center = [sim.obstacle_center...]
            if event.key == Keyboard.w
                new_center[2] += speed # Move up in Y
            elseif event.key == Keyboard.s
                new_center[2] -= speed # Move down in Y
            elseif event.key == Keyboard.a
                new_center[1] -= speed # Move left in X
            elseif event.key == Keyboard.d
                new_center[1] += speed # Move right in X
            elseif event.key == Keyboard.escape
                # Close the window
                sim.fig.scene.events.window_open[] = false
                return
            end
            sim.obstacle_center = (clamp(new_center[1],1.0,Float64(sim.NX)),
                                   clamp(new_center[2],1.0,Float64(sim.NY)),
                                   clamp(new_center[3],1.0,Float64(sim.NZ)))
        end
    end
end

function run_simulation(sim::FluidSim3D, max_steps)
    e8_vectors = initialize_e8_vectors(1000)
    display(sim.fig)
    try
        # Trigger one visualization call at the start to register events
        visualize(sim)
        
        for t in 1:max_steps
            inflow_u = 2.0+0.005*sum(v[1] for v in e8_vectors)*exp(-sim.dt*t*0.01)
            inflow_v = 0.005*sum(v[2] for v in e8_vectors)*exp(-sim.dt*t*0.02)
            inflow_w = 0.005*sum(v[3] for v in e8_vectors)*exp(-sim.dt*t*0.03)

            step!(sim.grids,sim.dt,sim.visc,sim.diff,sim.iterations,sim.NX,sim.NY,sim.NZ,
                  inflow_u,inflow_v,inflow_w,sim.obstacle_center,sim.obstacle_radius)

            if t % 1 == 0
                visualize(sim)
                sleep(1.0/60.0)
            end
            if t % 500 == 0; println("Step $t completed"); end
        end
    catch e; println("Simulation interrupted: $e"); showerror(stdout, e, catch_backtrace()); end
    println("Simulation finished. Window will remain open.")
end

end # module

function main()
    sim = DULA_E8.FluidSim3D(64, 64, 64)
    DULA_E8.run_simulation(sim, 10000)
end

if abspath(PROGRAM_FILE) == @__FILE__
    main()
end