import pyglet
import moderngl
import numpy as np
from pathlib import Path

# --- E8 and Primes part from original (CPU-side setup) ---
def chi(n):
    if n % 2 == 0 or n % 3 == 0: return 0
    if n % 6 == 1: return 1
    if n % 6 == 5: return -1

def is_prime(n):
    if n <= 1: return False
    if n <= 3: return True
    if n % 2 == 0 or n % 3 == 0: return False
    i = 5
    while i * i <= n:
        if n % i == 0 or n % (i + 2) == 0: return False
        i += 6
    return True

def e8_root(p, chi_p):
    if chi_p == 0: return np.zeros(8)
    scale = np.log(p) / np.sqrt(2)
    np.random.seed(p)
    v_p = np.random.random(8)
    v_p /= np.linalg.norm(v_p)
    return chi_p * scale * v_p

def weyl_reflection(v, plane_normal):
    plane_normal = plane_normal / np.linalg.norm(plane_normal)
    return v - 2 * np.dot(v, plane_normal) * plane_normal

class FluidSimGL(pyglet.window.Window):
    def __init__(self, width, height, **kwargs):
        super().__init__(width, height, "Navier-Stokes GLSL Simulation", vsync=True, **kwargs)
        self.ctx = moderngl.create_context()

        # Simulation parameters
        self.width, self.height = width, height
        self.dt = 0.016 # Adjusted for smoother animation
        self.visc = 0.00005
        self.diff = 0.0001
        self.iterations = 20
        self.force_scale = 0.005
        self.time = 0.0
        # MODIFIED: Added a multiplier to control the visual speed of the fluid
        self.advection_multiplier = 150.0

        # Cylinder state
        self.cyl_pos = np.array([self.width / 4, self.height / 2], dtype='f4')
        self.cyl_r = self.height / 10
        self.dragging = False

        # --- E8 Setup ---
        N_primes = 1000
        initial_primes = [p for p in range(2, N_primes + 1) if is_prime(p)]
        plane_normal = np.array([1.0, 0, 0, 0, 0, 0, 0, 0])
        self.reflected_vectors = []
        for p in initial_primes:
            chi_p = chi(p)
            v_p_ref = e8_root(p, chi_p) if chi_p != 0 else np.zeros(8)
            v_p_ref = weyl_reflection(v_p_ref, plane_normal)
            self.reflected_vectors.append((p, v_p_ref))

        # --- GLSL Setup ---
        self.quad_fs = self.ctx.buffer(np.array([-1, -1, -1, 1, 1, -1, 1, 1], 'f4'))
        self.load_shaders()

        self.vaos = {}
        for name, prog in self.progs.items():
             self.vaos[name] = self.ctx.vertex_array(
                prog,
                [(self.quad_fs, '2f', 'in_vert')]
            )

        # Framebuffers and Textures
        self.textures = {
            'vel': [self.create_texture(), self.create_texture()],
            'dens': [self.create_texture('r32f'), self.create_texture('r32f')],
            'pres': [self.create_texture('r32f'), self.create_texture('r32f')],
            'div': self.create_texture('r32f')
        }
        self.fbos = {
            'vel': [self.ctx.framebuffer(self.textures['vel'][0]), self.ctx.framebuffer(self.textures['vel'][1])],
            'dens': [self.ctx.framebuffer(self.textures['dens'][0]), self.ctx.framebuffer(self.textures['dens'][1])],
            'pres': [self.ctx.framebuffer(self.textures['pres'][0]), self.ctx.framebuffer(self.textures['pres'][1])],
            'div': self.ctx.framebuffer(self.textures['div'])
        }

        self.force_fbo = self.ctx.framebuffer(
            color_attachments=(self.textures['vel'][0], self.textures['dens'][0])
        )

        pyglet.clock.schedule_interval(self.update, 1 / 60.0)

        # Initialize on-screen display labels
        self.init_ui_labels()

    def init_ui_labels(self):
        """Initialize UI labels for parameter display"""
        self.labels = []
        label_color = (255, 255, 255, 255)  # White text

        # Parameter labels
        self.labels.append(pyglet.text.Label(
            f"Timestep: {self.dt:.4f}", x=10, y=self.height - 30,
            color=label_color, font_size=12
        ))
        self.labels.append(pyglet.text.Label(
            f"Viscosity: {self.visc:.6f}", x=10, y=self.height - 50,
            color=label_color, font_size=12
        ))
        self.labels.append(pyglet.text.Label(
            f"Diffusion: {self.diff:.6f}", x=10, y=self.height - 70,
            color=label_color, font_size=12
        ))
        self.labels.append(pyglet.text.Label(
            f"Force Scale: {self.force_scale:.6f}", x=10, y=self.height - 90,
            color=label_color, font_size=12
        ))
        self.labels.append(pyglet.text.Label(
            f"Advection Speed: {self.advection_multiplier:.1f}", x=10, y=self.height - 110,
            color=label_color, font_size=12
        ))
        self.labels.append(pyglet.text.Label(
            f"Iterations: {self.iterations}", x=10, y=self.height - 130,
            color=label_color, font_size=12
        ))

        # Add instructions label
        self.labels.append(pyglet.text.Label(
            "Controls: Q/W: Timestep  A/S: Viscosity  Z/X: Diffusion",
            x=10, y=self.height - 160, color=label_color, font_size=9
        ))
        self.labels.append(pyglet.text.Label(
            "         E/R: Force Scale  D/F: Speed  C/V: Iterations  Shift+R: Reset",
            x=10, y=self.height - 175, color=label_color, font_size=9
        ))

    def update_labels(self):
        """Update parameter display labels"""
        self.labels[0].text = f"Timestep: {self.dt:.4f}"
        self.labels[1].text = f"Viscosity: {self.visc:.6f}"
        self.labels[2].text = f"Diffusion: {self.diff:.6f}"
        self.labels[3].text = f"Force Scale: {self.force_scale:.6f}"
        self.labels[4].text = f"Advection Speed: {self.advection_multiplier:.1f}"
        self.labels[5].text = f"Iterations: {self.iterations}"

    def create_texture(self, components='rg32f'):
        tex = self.ctx.texture((self.width, self.height), components=2 if 'rg' in components else 1, dtype='f4')
        tex.filter = (moderngl.LINEAR, moderngl.LINEAR)
        tex.repeat_x = tex.repeat_y = False
        return tex

    def load_shaders(self):
        shader_path = Path(__file__).parent / 'shaders'
        with open(shader_path / 'fullscreen.vert') as f:
            vert_shader = f.read()
        
        self.progs = {}
        for name in ['advect', 'jacobi', 'divergence', 'gradient', 'boundary', 'force', 'display']:
            with open(shader_path / f'{name}.frag') as f:
                frag_shader = f.read()
            self.progs[name] = self.ctx.program(vertex_shader=vert_shader, fragment_shader=frag_shader)

    def swap(self, field):
        self.textures[field][0], self.textures[field][1] = self.textures[field][1], self.textures[field][0]
        self.fbos[field][0], self.fbos[field][1] = self.fbos[field][1], self.fbos[field][0]

    def on_draw(self):
        self.ctx.screen.use()
        self.ctx.clear(0.67, 0.84, 0.9, 1.0)

        prog = self.progs['display']
        prog['u_velocity_texture'].value = 0
        prog['u_density_texture'].value = 1
        prog['u_texel_size'].value = (1 / self.width, 1 / self.height)

        self.textures['vel'][0].use(0)
        self.textures['dens'][0].use(1)

        self.vaos['display'].render(mode=moderngl.TRIANGLE_STRIP)

        # Render UI labels
        for label in self.labels:
            label.draw()

    def on_mouse_press(self, x, y, button, modifiers):
        dist_sq = (x - self.cyl_pos[0])**2 + (y - self.cyl_pos[1])**2
        if dist_sq < self.cyl_r**2:
            self.dragging = True
    
    def on_mouse_release(self, x, y, button, modifiers):
        self.dragging = False

    def on_mouse_drag(self, x, y, dx, dy, buttons, modifiers):
        if self.dragging:
            self.cyl_pos += np.array([dx, dy], dtype='f4')
            self.cyl_pos[0] = np.clip(self.cyl_pos[0], self.cyl_r, self.width - self.cyl_r)
            self.cyl_pos[1] = np.clip(self.cyl_pos[1], self.cyl_r, self.height - self.cyl_r)

    def on_key_press(self, symbol, modifiers):
        """Handle keyboard input for parameter adjustment"""
        adjustment_factor = 1.1  # 10% adjustment
        altered = False

        # Timestep (Q/W)
        if symbol == pyglet.window.key.Q:
            self.dt = max(0.001, self.dt / adjustment_factor)  # Minimum 0.001
            altered = True
        elif symbol == pyglet.window.key.W:
            self.dt = min(0.1, self.dt * adjustment_factor)   # Maximum 0.1
            altered = True

        # Viscosity (A/S)
        elif symbol == pyglet.window.key.A:
            self.visc = max(0.0, self.visc / adjustment_factor)
            altered = True
        elif symbol == pyglet.window.key.S:
            self.visc = min(0.01, self.visc * adjustment_factor)
            altered = True

        # Diffusion (Z/X)
        elif symbol == pyglet.window.key.Z:
            self.diff = max(0.0, self.diff / adjustment_factor)
            altered = True
        elif symbol == pyglet.window.key.X:
            self.diff = min(0.01, self.diff * adjustment_factor)
            altered = True

        # Force Scale (E/R)
        elif symbol == pyglet.window.key.E:
            self.force_scale = max(0.0001, self.force_scale / adjustment_factor)
            altered = True
        elif symbol == pyglet.window.key.R:
            self.force_scale = min(0.1, self.force_scale * adjustment_factor)
            altered = True

        # Advection Speed (D/F)
        elif symbol == pyglet.window.key.D:
            self.advection_multiplier = max(1.0, self.advection_multiplier / adjustment_factor)
            altered = True
        elif symbol == pyglet.window.key.F:
            self.advection_multiplier = min(500.0, self.advection_multiplier * adjustment_factor)
            altered = True

        # Iterations (C/V)
        elif symbol == pyglet.window.key.C:
            self.iterations = max(1, self.iterations - 1)
            altered = True
        elif symbol == pyglet.window.key.V:
            self.iterations = min(50, self.iterations + 1)
            altered = True

        # Reset to defaults (R key with modifiers)
        elif symbol == pyglet.window.key.R and (modifiers & pyglet.window.key.MOD_SHIFT):
            self.dt = 0.016
            self.visc = 0.00005
            self.diff = 0.0001
            self.iterations = 20
            self.force_scale = 0.005
            self.advection_multiplier = 150.0
            altered = True

        if altered:
            self.update_labels()

    def update(self, dt_in):
        texel_size = (1 / self.width, 1 / self.height)

        # Advection steps
        for field in ['vel', 'dens']:
            self.fbos[field][1].use()
            prog = self.progs['advect']
            # MODIFIED: Amplify dt for advection to make the fluid move at a visible speed
            prog['u_dt'].value = self.dt * self.advection_multiplier
            prog['u_texel_size'].value = texel_size
            prog['u_velocity_texture'].value = 0
            prog['u_source_texture'].value = 1
            self.textures['vel'][0].use(0)
            self.textures[field][0].use(1)
            self.vaos['advect'].render(mode=moderngl.TRIANGLE_STRIP)
            self.swap(field)

        # E8 Inflow and Obstacle
        v_sum = np.zeros(8)
        for p, v_p_ref in self.reflected_vectors:
            if np.linalg.norm(v_p_ref) > 0:
                decay = np.exp(-self.time * np.log(p))
                v_sum += v_p_ref * decay
        
        inflow_u = 2.0 + self.force_scale * v_sum[0] # Increased base inflow
        inflow_v = self.force_scale * v_sum[1]

        self.force_fbo.use()
        prog = self.progs['force']
        prog['u_resolution'].value = (self.width, self.height)
        prog['u_velocity_texture'].value = 0
        prog['u_density_texture'].value = 1
        prog['u_cyl_pos'].value = tuple(self.cyl_pos)
        prog['u_cyl_r'].value = self.cyl_r
        prog['u_inflow_u'].value = inflow_u
        prog['u_inflow_v'].value = inflow_v
        self.textures['vel'][0].use(0)
        self.textures['dens'][0].use(1)
        self.vaos['force'].render(mode=moderngl.TRIANGLE_STRIP)
        
        # Projection Step
        self.fbos['div'].use()
        prog = self.progs['divergence']
        prog['u_velocity_texture'].value = 0
        prog['u_texel_size'].value = texel_size
        self.textures['vel'][0].use(0)
        self.vaos['divergence'].render(mode=moderngl.TRIANGLE_STRIP)

        prog = self.progs['jacobi']
        prog['u_alpha'].value = -1.0
        prog['u_beta'].value = 4.0
        prog['u_texel_size'].value = texel_size
        for _ in range(self.iterations):
            self.fbos['pres'][1].use()
            prog['u_texture_x'].value = 0
            prog['u_texture_b'].value = 1
            self.textures['pres'][0].use(0)
            self.textures['div'].use(1)
            self.vaos['jacobi'].render(mode=moderngl.TRIANGLE_STRIP)
            self.swap('pres')

        self.fbos['vel'][1].use()
        prog = self.progs['gradient']
        prog['u_velocity_texture'].value = 0
        prog['u_pressure_texture'].value = 1
        prog['u_texel_size'].value = texel_size
        self.textures['vel'][0].use(0)
        self.textures['pres'][0].use(1)
        self.vaos['gradient'].render(mode=moderngl.TRIANGLE_STRIP)
        self.swap('vel')
        
        # Boundary Conditions
        self.fbos['vel'][1].use()
        prog = self.progs['boundary']
        prog['u_texture'].value = 0
        prog['u_scale_x'].value = -1.0
        prog['u_scale_y'].value = -1.0
        self.textures['vel'][0].use(0)
        self.vaos['boundary'].render(mode=moderngl.TRIANGLE_STRIP)
        self.swap('vel')

        self.time += self.dt

if __name__ == '__main__':
    FluidSimGL(width=800, height=600)
    pyglet.app.run()
