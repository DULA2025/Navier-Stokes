import pyglet
import moderngl
import numpy as np
from pathlib import Path
from leech_lattice import generate_leech_vectors  # Import the Leech vector generator

class FluidSimGL(pyglet.window.Window):
    """
    A real-time 2D Navier-Stokes fluid simulation where the inflow force
    is modulated by a projection of vectors from the 24-dimensional Leech lattice.
    This version includes Coriolis forces to simulate rotation and periodic
    boundary conditions, and advanced visualization of the fluid's vorticity.
    """
    def __init__(self, width, height, **kwargs):
        super().__init__(width, height, "24D Leech Lattice Rotating Fluid Simulation", vsync=True, resizable=True, **kwargs)
        self.ctx = moderngl.create_context()

        # Simulation parameters (tunable via keyboard)
        self.dt = 0.016
        self.visc = 0.00001
        self.iterations = 30
        self.force_scale = 0.02
        self.time = 0.0
        self.advection_multiplier = 150.0
        self.coriolis_f = 0.2

        # Obstacle state
        self.cyl_pos = np.array([self.width / 2, self.height / 2], dtype='f4')
        self.cyl_r = self.height / 10
        self.dragging = False

        # --- Leech Lattice (Λ₂₄) Setup ---
        num_vectors = 256
        self.leech_vectors = generate_leech_vectors(num_vectors)
        print(f"Generated {len(self.leech_vectors)} Leech Lattice vectors for the simulation.")

        # --- GLSL Setup ---
        self.quad_fs = self.ctx.buffer(np.array([[-1.0, -1.0], [1.0, -1.0], [-1.0, 1.0], [1.0, 1.0]], 'f4'))
        self.quad_uv = self.ctx.buffer(np.array([[0.0, 0.0], [1.0, 0.0], [0.0, 1.0], [1.0, 1.0]], 'f4'))
        self.load_shaders()

        self.vaos = {}
        for name, prog in self.progs.items():
            content = [(self.quad_fs, '2f', 'in_vert')]
            if name == 'display':
                content.append((self.quad_uv, '2f', 'in_uv'))
            self.vaos[name] = self.ctx.vertex_array(
                prog,
                content
            )

        self.init_framebuffers()
        pyglet.clock.schedule_interval(self.update, 1 / 60.0)
        self.init_ui_labels()

    def init_framebuffers(self):
        """Create all necessary textures and framebuffer objects."""
        if hasattr(self, 'textures'):
            for tex_list in self.textures.values():
                tex_collection = tex_list if isinstance(tex_list, list) else [tex_list]
                for tex in tex_collection:
                    tex.release()

        self.textures = {
            'vel': [self.create_texture(), self.create_texture()],
            'dens': [self.create_texture('r32f'), self.create_texture('r32f')],
            'pres': [self.create_texture('r32f'), self.create_texture('r32f')],
            'div': self.create_texture('r32f'),
            'curl': self.create_texture('r32f')
        }
        self.fbos = {
            'vel': [self.ctx.framebuffer(self.textures['vel'][0]), self.ctx.framebuffer(self.textures['vel'][1])],
            'dens': [self.ctx.framebuffer(self.textures['dens'][0]), self.ctx.framebuffer(self.textures['dens'][1])],
            'pres': [self.ctx.framebuffer(self.textures['pres'][0]), self.ctx.framebuffer(self.textures['pres'][1])],
            'div': self.ctx.framebuffer(self.textures['div']),
            'curl': self.ctx.framebuffer(self.textures['curl'])
        }
        self.force_fbo = self.ctx.framebuffer(
            color_attachments=(self.textures['vel'][1], self.textures['dens'][1])
        )

        # Clear all framebuffers to ensure zero initialization
        for field_fbos in self.fbos.values():
            if isinstance(field_fbos, list):
                for fbo in field_fbos:
                    fbo.use()
                    self.ctx.clear(0.0, 0.0, 0.0, 0.0)
            else:
                field_fbos.use()
                self.ctx.clear(0.0, 0.0, 0.0, 0.0)
        self.force_fbo.use()
        self.ctx.clear(0.0, 0.0, 0.0, 0.0)

    def on_resize(self, width, height):
        """Handle window resizing by re-creating textures and FBOs."""
        super().on_resize(width, height)
        self.init_framebuffers()
        self.init_ui_labels()
        print(f"Window resized to {width}x{height}")

    def init_ui_labels(self):
        """Initialize UI labels for parameter display."""
        self.labels = []
        label_color = (255, 255, 255, 255)
        y_pos = self.height - 30
        self.labels.append(pyglet.text.Label(f"Leech Lattice (24D) Rotating Fluid", x=10, y=y_pos, bold=True, color=label_color, font_size=14))
        y_pos -= 30
        self.labels.append(pyglet.text.Label(f"Timestep: {self.dt:.4f}", x=10, y=y_pos, color=label_color, font_size=12))
        y_pos -= 20
        self.labels.append(pyglet.text.Label(f"Viscosity: {self.visc:.6f}", x=10, y=y_pos, color=label_color, font_size=12))
        y_pos -= 20
        self.labels.append(pyglet.text.Label(f"Force Scale: {self.force_scale:.4f}", x=10, y=y_pos, color=label_color, font_size=12))
        y_pos -= 20
        self.labels.append(pyglet.text.Label(f"Advection Speed: {self.advection_multiplier:.1f}", x=10, y=y_pos, color=label_color, font_size=12))
        y_pos -= 20
        self.labels.append(pyglet.text.Label(f"Iterations: {self.iterations}", x=10, y=y_pos, color=label_color, font_size=12))
        y_pos -= 20
        self.labels.append(pyglet.text.Label(f"Coriolis (Rotation): {self.coriolis_f:.3f}", x=10, y=y_pos, color=label_color, font_size=12))
        y_pos -= 30
        self.labels.append(pyglet.text.Label("Controls: Q/W: Timestep, A/S: Visc, E/R: Force", x=10, y=y_pos, color=label_color, font_size=9))
        y_pos -= 15
        self.labels.append(pyglet.text.Label("D/F: Speed, C/V: Iters, T/G: Coriolis, Shift+R: Reset", x=10, y=y_pos, color=label_color, font_size=9))

    def update_labels(self):
        """Update parameter display labels."""
        self.labels[1].text = f"Timestep: {self.dt:.4f}"
        self.labels[2].text = f"Viscosity: {self.visc:.6f}"
        self.labels[3].text = f"Force Scale: {self.force_scale:.4f}"
        self.labels[4].text = f"Advection Speed: {self.advection_multiplier:.1f}"
        self.labels[5].text = f"Iterations: {self.iterations}"
        self.labels[6].text = f"Coriolis (Rotation): {self.coriolis_f:.3f}"

    def create_texture(self, components='rg32f'):
        """Helper to create a standard floating point texture."""
        tex = self.ctx.texture((self.width, self.height), components=2 if 'rg' in components else 1, dtype='f4')
        tex.filter = (moderngl.LINEAR, moderngl.LINEAR)
        tex.repeat_x = tex.repeat_y = True
        return tex

    def load_shaders(self):
        """Load all GLSL shaders from the 'shaders' directory."""
        shader_path = Path(__file__).parent / 'shaders'
        with open(shader_path / 'fullscreen.vert') as f:
            vert_shader = f.read()
        self.progs = {}
        shader_names = ['advect', 'jacobi', 'divergence', 'gradient', 'force', 'display', 'curl']
        for name in shader_names:
            try:
                with open(shader_path / f'{name}.frag') as f:
                    frag_shader = f.read()
                self.progs[name] = self.ctx.program(vertex_shader=vert_shader, fragment_shader=frag_shader)
            except FileNotFoundError:
                print(f"Error: Shader file not found: shaders/{name}.frag")
                pyglet.app.exit()

    def swap(self, field):
        """Swap the read/write textures for a given field."""
        self.textures[field][0], self.textures[field][1] = self.textures[field][1], self.textures[field][0]
        self.fbos[field][0], self.fbos[field][1] = self.fbos[field][1], self.fbos[field][0]

    def on_draw(self):
        """Main rendering callback."""
        self.ctx.screen.use()
        self.ctx.clear(0.1, 0.1, 0.15, 1.0)

        prog = self.progs['display']
        prog['u_velocity_texture'].value = 0
        prog['u_density_texture'].value = 1

        self.textures['vel'][0].use(0)
        self.textures['dens'][0].use(1)
        self.vaos['display'].render(mode=moderngl.TRIANGLE_STRIP)

        for label in self.labels:
            label.draw()

    def on_mouse_press(self, x, y, button, modifiers):
        dist_sq = (x - self.cyl_pos[0])**2 + (y - self.cyl_pos[1])**2
        if dist_sq < self.cyl_r**2:
            self.dragging = True

    def on_mouse_release(self, x, y, button, modifiers):
        self.dragging = False

    def on_mouse_drag(self, x, y, dx, dy, buttons, modifiers):
        if self.dragging:
            self.cyl_pos += np.array([dx, dy], dtype='f4')
            self.cyl_pos[0] %= self.width
            self.cyl_pos[1] %= self.height

    def on_key_press(self, symbol, modifiers):
        """Handle keyboard input for parameter adjustment."""
        adj = 1.1
        altered = True
        if symbol == pyglet.window.key.Q: self.dt = max(0.001, self.dt / adj)
        elif symbol == pyglet.window.key.W: self.dt = min(0.1, self.dt * adj)
        elif symbol == pyglet.window.key.A: self.visc = max(0.0, self.visc / adj)
        elif symbol == pyglet.window.key.S: self.visc = min(0.01, self.visc * adj)
        elif symbol == pyglet.window.key.E: self.force_scale = max(0.0001, self.force_scale / adj)
        elif symbol == pyglet.window.key.R: self.force_scale = min(0.1, self.force_scale * adj)
        elif symbol == pyglet.window.key.D: self.advection_multiplier = max(1.0, self.advection_multiplier / adj)
        elif symbol == pyglet.window.key.F: self.advection_multiplier = min(500.0, self.advection_multiplier * adj)
        elif symbol == pyglet.window.key.C: self.iterations = max(1, self.iterations - 1)
        elif symbol == pyglet.window.key.V: self.iterations = min(100, self.iterations + 1)
        elif symbol == pyglet.window.key.T: self.coriolis_f = max(0.0, self.coriolis_f / adj)
        elif symbol == pyglet.window.key.G: self.coriolis_f = min(2.0, self.coriolis_f * adj)
        elif symbol == pyglet.window.key.R and (modifiers & pyglet.window.key.MOD_SHIFT):
            self.dt, self.visc, self.iterations, self.force_scale, self.advection_multiplier, self.coriolis_f = 0.016, 0.00001, 30, 0.02, 150.0, 0.2
        else: altered = False

        if altered: self.update_labels()

    def update(self, dt_in):
        """Main simulation update loop, called every frame."""
        texel_size = (1 / self.width, 1 / self.height)

        # Advect velocity and density fields
        for field in ['vel', 'dens']:
            self.fbos[field][1].use()
            prog = self.progs['advect']
            prog['u_dt'].value = self.dt * self.advection_multiplier
            prog['u_texel_size'].value = texel_size
            prog['u_velocity_texture'].value = 0
            prog['u_source_texture'].value = 1
            self.textures['vel'][0].use(0)
            self.textures[field][0].use(1)
            self.vaos['advect'].render(mode=moderngl.TRIANGLE_STRIP)
            self.swap(field)

        # Leech Lattice Force Calculation
        v_sum = np.zeros(24)
        num_active_vectors = 32
        start_index = int(self.time * 10) % (len(self.leech_vectors) - num_active_vectors)

        for i in range(num_active_vectors):
            vec = self.leech_vectors[start_index + i]
            decay = np.sin(self.time * 0.1 * (i + 1) + i)
            v_sum += vec * decay

        inflow_u = self.force_scale * v_sum[0]
        inflow_v = self.force_scale * v_sum[1]

        # Apply forces
        self.force_fbo.use()
        prog = self.progs['force']
        prog['u_velocity_texture'].value = 0
        prog['u_density_texture'].value = 1
        prog['u_cyl_pos'].value = tuple(self.cyl_pos)
        prog['u_cyl_r'].value = self.cyl_r
        prog['u_inflow_u'].value = inflow_u
        prog['u_inflow_v'].value = inflow_v
        prog['u_coriolis_f'].value = self.coriolis_f
        prog['u_dt'].value = self.dt
        self.textures['vel'][0].use(0)
        self.textures['dens'][0].use(1)
        self.vaos['force'].render(mode=moderngl.TRIANGLE_STRIP)
        self.swap('vel')
        self.swap('dens')

        # Projection Step
        self.fbos['div'].use()
        prog = self.progs['divergence']
        prog['u_velocity_texture'].value = 0
        prog['u_texel_size'].value = texel_size
        self.textures['vel'][0].use(0)
        self.vaos['divergence'].render(mode=moderngl.TRIANGLE_STRIP)

        prog = self.progs['jacobi']
        prog['u_alpha'].value = -1.0
        prog['u_beta'].value = 4.0
        prog['u_texel_size'].value = texel_size
        for _ in range(self.iterations):
            self.fbos['pres'][1].use()
            prog['u_texture_x'].value = 0
            prog['u_texture_b'].value = 1
            self.textures['pres'][0].use(0)
            self.textures['div'].use(1)
            self.vaos['jacobi'].render(mode=moderngl.TRIANGLE_STRIP)
            self.swap('pres')

        self.fbos['vel'][1].use()
        prog = self.progs['gradient']
        prog['u_velocity_texture'].value = 0
        prog['u_pressure_texture'].value = 1
        prog['u_texel_size'].value = texel_size
        self.textures['vel'][0].use(0)
        self.textures['pres'][0].use(1)
        self.vaos['gradient'].render(mode=moderngl.TRIANGLE_STRIP)
        self.swap('vel')

        # Compute Vorticity (Curl) for visualization
        self.fbos['curl'].use()
        prog = self.progs['curl']
        prog['u_velocity_texture'].value = 0
        prog['u_texel_size'].value = texel_size
        self.textures['vel'][0].use(0)
        self.vaos['curl'].render(mode=moderngl.TRIANGLE_STRIP)

        self.time += self.dt

if __name__ == '__main__':
    window = FluidSimGL(width=1280, height=720)
    pyglet.app.run()
