import numpy as np

def generate_leech_vectors(num_vectors):
    """
    Generates a specified number of vectors from the Leech Lattice (Λ₂₄).
    This uses the standard extended binary Golay code generator matrix
    for a more accurate construction.
    """
    # Standard generator matrix for the extended binary Golay code: [I_12 | A]
    A_golay = np.array([
        [1, 0, 1, 0, 1, 1, 1, 0, 0, 0, 1, 1],
        [1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1, 0],
        [1, 1, 0, 1, 0, 0, 1, 0, 1, 0, 1, 1],
        [1, 1, 0, 0, 0, 1, 1, 1, 0, 1, 1, 0],
        [1, 1, 0, 0, 1, 1, 0, 1, 1, 0, 0, 1],
        [0, 1, 1, 0, 0, 1, 1, 0, 1, 1, 0, 1],
        [0, 0, 1, 1, 0, 0, 1, 1, 0, 1, 1, 1],
        [1, 0, 1, 1, 0, 1, 1, 1, 1, 0, 0, 0],
        [0, 1, 0, 1, 1, 0, 1, 1, 1, 1, 0, 0],
        [0, 0, 1, 0, 1, 1, 0, 1, 1, 1, 1, 0],
        [1, 0, 1, 1, 1, 0, 0, 0, 1, 1, 0, 1],
        [0, 1, 0, 1, 1, 1, 0, 0, 0, 1, 1, 1]
    ], dtype=np.int32)

    I12 = np.identity(12, dtype=np.int32)
    generator_matrix = np.hstack([I12, A_golay])

    # Generate codewords from the Golay code
    codewords = []
    # Generate a subset of codewords for efficiency
    num_codewords_to_generate = min(2**12, num_vectors * 2)
    np.random.seed(42)  # For reproducibility
    for _ in range(num_codewords_to_generate):
        input_word = np.random.randint(0, 2, 12, dtype=np.int32)
        codeword = (input_word @ generator_matrix) % 2
        weight = np.sum(codeword)
        if weight % 4 == 0:  # All Golay codewords satisfy this, but retained for consistency
            codewords.append(codeword)
    print(f"Generated {len(codewords)} suitable Golay codewords.")

    # Use the codewords to construct Leech lattice-inspired vectors
    vectors = []
    for cw in codewords:
        if len(vectors) >= num_vectors:
            break
        v = np.zeros(24, dtype=np.float32)
        for i in range(24):
            v[i] = (2 * cw[i] - 1) * 2
        weight = np.sum(cw)
        if weight == 8 or weight == 12:
            v /= 2
        if np.linalg.norm(v) > 0:
            vectors.append(v / np.linalg.norm(v))  # Normalize for simulation stability

    # Add additional vectors if needed
    if len(vectors) < num_vectors:
        base_v = np.zeros(24)
        base_v[0], base_v[1] = 4, 4
        if np.linalg.norm(base_v) > 0:
            vectors.append(base_v / np.linalg.norm(base_v))

    if len(vectors) < num_vectors:
        base_v = np.zeros(24)
        base_v[0], base_v[1] = -4, 4
        if np.linalg.norm(base_v) > 0:
            vectors.append(base_v / np.linalg.norm(base_v))

    # Pad by cycling if still short
    while len(vectors) < num_vectors:
        vectors.extend(vectors[:num_vectors - len(vectors)])

    np.random.shuffle(vectors)
    return vectors[:num_vectors]